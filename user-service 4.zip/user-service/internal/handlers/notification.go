package handlers

import (
	"diplom/user-service/internal/models"
	"encoding/json"
	"github.com/gofiber/fiber/v3"
	"net/http"
)

func (h *Handler) SendPush(c fiber.Ctx) error {
	var req models.PushRequest
	err := json.Unmarshal(c.Body(), &req)
	if err != nil {
		h.logger.Error("Error unmarshalling body", "error", err)
		return c.Status(http.StatusBadRequest).JSON(err.Error())
	}

	err = h.services.SendPush(req.Token)
	if err != nil {
		h.logger.Error("Error sending push", "error", err)
		return c.Status(http.StatusInternalServerError).JSON(err.Error())
	}

	return c.Status(http.StatusOK).JSON("Success")
}
