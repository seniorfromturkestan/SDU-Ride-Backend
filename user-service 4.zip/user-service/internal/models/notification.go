package models

type PushRequest struct {
	Token string `json:"token"`
}
