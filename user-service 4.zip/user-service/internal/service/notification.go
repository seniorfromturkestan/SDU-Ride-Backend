package service

import (
	"context"
	firebase "firebase.google.com/go/v4"
	"firebase.google.com/go/v4/messaging"
	"google.golang.org/api/option"
)

func (s *Service) SendPush(token string) error {
	serviceAccountFile := "/firebase/sdubus-5d1da-firebase-adminsdk-fbsvc-5cd3cdecc8.json"
	ctx := context.Background()

	opt := option.WithCredentialsFile(serviceAccountFile)
	app, err := firebase.NewApp(ctx, nil, opt)
	if err != nil {
		return err
	}

	client, err := app.Messaging(ctx)
	if err != nil {
		return err
	}

	message := &messaging.Message{
		Token: token,
		Notification: &messaging.Notification{
			Title: "SDU BUS",
			Body:  "Вы успешно встали в очередь!",
		},
	}

	_, err = client.Send(ctx, message)
	if err != nil {
		return err
	}

	return nil
}
