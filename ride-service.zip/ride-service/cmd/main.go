package main

import (
	"diplom/ride-service/internal/app"
	"diplom/ride-service/pkg/config"
	"log"
)

func main() {
	conf, err := config.LoadConfigs()
	if err != nil {
		log.Fatalf("load conf failed, err:%v", err)
	}

	err = app.Start(conf)
	if err != nil {
		log.Fatalf("start app failed, err:%v", err)
	}
}
