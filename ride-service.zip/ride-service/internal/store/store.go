package store

import (
	"diplom/ride-service/internal/models"
	"github.com/jmoiron/sqlx"
)

type IStore interface {
	CheckRole(id int) (string, error)
	BeDriver(id int) error
	OrdersForUsers(route string) ([]models.OrderForUserResponse, error)
	CreateOrderUser(req models.UserOrder) error
	DeleteOrder(id int) error
	CronDelete()
}

type Store struct {
	db *sqlx.DB
}

func NewStore(db *sqlx.DB) *Store {
	return &Store{db: db}
}
