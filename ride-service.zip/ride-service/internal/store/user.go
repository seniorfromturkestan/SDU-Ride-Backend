package store

import (
	"diplom/ride-service/internal/models"
	"log"
)

func (s *Store) CreateOrderUser(req models.UserOrder) error {
	query := `INSERT INTO orders (
    	creator_id,
    	creator_role,
    	direction,
    	status,
    	amount
	) VALUES (
    	$1, $2, $3, $4, $5
	)`

	_, err := s.db.Exec(query, req.CreatorId, req.CreatorRole, req.Direction, "created", req.Amount)
	return err
}

func (s *Store) CheckRole(id int) (string, error) {
	var role string
	query := `SELECT role FROM users WHERE student_id = $1`

	rows, err := s.db.Query(query, id)
	if err != nil {
		return "", err
	}
	defer rows.Close()

	for rows.Next() {
		if err := rows.Scan(&role); err != nil {
			return "", err
		}
	}

	return role, nil
}

func (s *Store) BeDriver(id int) error {
	query := `UPDATE users SET role = 'driver' WHERE student_id = $1`

	_, err := s.db.Exec(query, id)
	if err != nil {
		return err
	}

	return nil
}

func (s *Store) OrdersForUsers(route string) ([]models.OrderForUserResponse, error) {
	query := `SELECT o.id, u.phone, u.name, o.amount, o.direction FROM orders o JOIN users u ON o.creator_id = u.id WHERE o.status = 'created' AND u.role = 'driver' AND o.direction = $1`

	rows, err := s.db.Query(query, route)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var orders []models.OrderForUserResponse
	for rows.Next() {
		var order models.OrderForUserResponse
		err = rows.Scan(&order.Id, &order.Phone, &order.Name, &order.Amount, &order.Route)
		if err != nil {
			return nil, err
		}
		orders = append(orders, order)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	return orders, nil
}

func (s *Store) DeleteOrder(id int) error {
	query := `DELETE FROM orders WHERE id = $1`
	_, err := s.db.Exec(query, id)
	if err != nil {
		return err
	}

	return nil
}

func (s *Store) CronDelete() {
	query := `
        DELETE FROM orders
        WHERE created_at < NOW() - INTERVAL '30 minutes'
    `
	result, err := s.db.Exec(query)
	if err != nil {
		log.Printf("error deleting old orders: %v", err)
		return
	}

	count, _ := result.RowsAffected()
	log.Printf("deleted %d old orders", count)
}
