package service

import (
	"diplom/ride-service/internal/models"
	"diplom/ride-service/internal/store"
)

type IService interface {
	BeDriver(id int) error
	OrdersForUsers(route string) ([]models.OrderForUserResponse, error)
	CreateOrderUser(req models.UserOrder) error
	DeleteOrder(id string) error
}

type Service struct {
	store store.IStore
}

func NewService(store store.IStore) *Service {
	return &Service{
		store: store,
	}
}
