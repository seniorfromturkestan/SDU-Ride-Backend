package service

import (
	"diplom/ride-service/internal/models"
	"errors"
	"strconv"
)

func (s *Service) DeleteOrder(id string) error {
	idInt, err := strconv.Atoi(id)
	if err != nil {
		return err
	}

	err = s.store.DeleteOrder(idInt)
	if err != nil {
		return err
	}

	return nil
}

func (s *Service) CreateOrderUser(req models.UserOrder) error {
	err := s.store.CreateOrderUser(req)
	if err != nil {
		return err
	}

	return nil
}

func (s *Service) BeDriver(id int) error {
	role, err := s.store.CheckRole(id)
	if err != nil {
		return err
	}

	if role == "" || role == "driver" {
		return errors.New("can't change role to driver")
	}

	err = s.store.BeDriver(id)
	if err != nil {
		return err
	}

	return nil
}

func (s *Service) OrdersForUsers(route string) ([]models.OrderForUserResponse, error) {
	resp, err := s.store.OrdersForUsers(route)
	if err != nil {
		return nil, err
	}

	return resp, nil
}
