package handlers

import (
	"diplom/ride-service/internal/models"
	"encoding/json"
	"github.com/gofiber/fiber/v3"
	"strconv"
)

func (h *Handler) BeDriver(c fiber.Ctx) error {
	id := c.Params("id")
	if len(id) == 0 {
		h.logger.Error("BeDriver", "id is required")
		return c.SendStatus(fiber.StatusBadRequest)
	}

	idInt, err := strconv.Atoi(id)
	if err != nil {
		h.logger.Error("BeDriver", "id is invalid")
		return c.SendStatus(fiber.StatusBadRequest)
	}

	err = h.service.BeDriver(idInt)
	if err != nil {
		h.logger.Error("Failed to change role", "error", err.Error())
		return c.Status(500).SendString(err.Error())
	}

	return c.SendStatus(fiber.StatusOK)
}

func (h *Handler) OrdersForUsers(c fiber.Ctx) error {
	route := c.Params("route")
	if len(route) == 0 {
		h.logger.Error("OrdersForUsers", "route is required")
		return c.SendStatus(fiber.StatusBadRequest)
	}

	resp, err := h.service.OrdersForUsers(route)
	if err != nil {
		h.logger.Error("OrdersForUsers", "error", err.Error())
		return c.SendStatus(fiber.StatusInternalServerError)
	}

	return c.Status(200).JSON(resp)
}

func (h *Handler) CreateOrderUser(c fiber.Ctx) error {
	req := new(models.UserOrder)
	err := json.Unmarshal(c.Body(), req)
	if err != nil {
		h.logger.Error("Failed to unmarshal json", "err", err)
		return c.SendStatus(fiber.StatusBadRequest)
	}

	if req.CreatorId == 0 || req.Amount == 0 || len(req.Direction) == 0 {
		return c.Status(400).JSON("One of the parameters is empty")
	}

	err = h.service.CreateOrderUser(*req)
	if err != nil {
		h.logger.Error("Failed to create order user", "err", err)
		return c.Status(500).JSON("Failed to create order user")
	}

	return c.Status(201).JSON("Create order user successfully")
}

func (h *Handler) DeleteOrder(c fiber.Ctx) error {
	id := c.Params("id")
	if len(id) == 0 {
		h.logger.Error("DeleteOrder", "id is required")
		return c.SendStatus(fiber.StatusBadRequest)
	}

	err := h.service.DeleteOrder(id)
	if err != nil {
		h.logger.Error("DeleteOrder", "error", err.Error())
		return c.SendStatus(fiber.StatusInternalServerError)
	}

	return c.SendStatus(fiber.StatusOK)
}
