package handlers

import (
	"diplom/ride-service/internal/service"
	"github.com/gofiber/fiber/v3"
	"github.com/hashicorp/go-hclog"
)

type IHandler interface {
	BeDriver(c fiber.Ctx) error
	OrdersForUsers(c fiber.Ctx) error
	CreateOrderUser(c fiber.Ctx) error
	DeleteOrder(c fiber.Ctx) error
}
type Handler struct {
	logger  hclog.Logger
	service service.IService
}

func NewHandlers(logger hclog.Logger, svc service.IService) *Handler {
	return &Handler{
		logger:  logger,
		service: svc,
	}
}
