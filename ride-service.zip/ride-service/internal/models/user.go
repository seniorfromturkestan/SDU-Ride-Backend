package models

type UserOrder struct {
	Id          int    `json:"id"`
	CreatorId   int    `json:"creator_id"`
	CreatorRole string `json:"creator_role"`
	Direction   string `json:"direction"`
	Status      string `json:"status"`
	AcceptedBy  string `json:"accepted_by"`
	Amount      int    `json:"amount"`
	CreatedAt   string `json:"created_at"`
}

type OrderForUserResponse struct {
	Id     int    `json:"id"`
	Phone  string `json:"phone"`
	Name   string `json:"name"`
	Route  string `json:"route"`
	Amount int    `json:"amount"`
}
