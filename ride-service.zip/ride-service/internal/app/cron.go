package app

import (
	"diplom/ride-service/internal/store"
	"github.com/robfig/cron/v3"
	"log"
)

func (s *server) cronDelete(st store.IStore) {
	cronJob := cron.New()

	_, err := cronJob.AddFunc("*/5 * * * *", st.CronDelete)
	if err != nil {
		log.Fatalf("failed to schedule cron job: %v", err)
	}

	cronJob.Start()

	log.Println("cron cleaner started")

	select {}
}
