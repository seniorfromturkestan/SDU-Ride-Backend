package app

import (
	"diplom/ride-service/internal/handlers"
	"diplom/ride-service/internal/service"
	"diplom/ride-service/internal/store"
	"diplom/ride-service/pkg/config"
	"diplom/ride-service/pkg/database"
	"github.com/gofiber/fiber/v3"
	"github.com/hashicorp/go-hclog"
)

type server struct {
	app      *fiber.App
	logger   hclog.Logger
	handlers handlers.IHandler
}

func (s *server) generate(conf *config.Config) {
	s.app = fiber.New()

	s.logger = hclog.New(&hclog.LoggerOptions{
		Level:      2,
		JSONFormat: true,
	})

	dbConnection, err := database.ConnectPostgres(conf.Db)
	if err != nil {
		s.logger.Error("Failed to connect to database", "error", err)
		return
	}

	stores := store.NewStore(dbConnection)
	services := service.NewService(stores)
	s.handlers = handlers.NewHandlers(s.logger, services)

	s.router()

	go func() {
		s.cronDelete(stores)
	}()
}
