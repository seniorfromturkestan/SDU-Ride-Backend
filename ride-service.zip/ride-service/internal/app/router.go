package app

func (s *server) router() {
	s.app.Post("/driver/:id", s.handlers.BeDriver)

	user := s.app.Group("/user")
	user.Post("/create-order", s.handlers.CreateOrderUser)
	user.Get("/orders/:route", s.handlers.OrdersForUsers)
	user.Delete("/delete-order/:id", s.handlers.DeleteOrder)
}
